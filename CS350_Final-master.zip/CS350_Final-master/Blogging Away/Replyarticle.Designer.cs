﻿namespace Blogging_Away
{
    partial class Replyarticle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelCreate = new System.Windows.Forms.Panel();
            this.panelConfirm = new System.Windows.Forms.Panel();
            this.btnConfirmPost = new System.Windows.Forms.Button();
            this.txtConfirmdetail = new System.Windows.Forms.TextBox();
            this.txtConfirmtitle = new System.Windows.Forms.TextBox();
            this.txtConfirmdate = new System.Windows.Forms.TextBox();
            this.txtConfirmusername = new System.Windows.Forms.TextBox();
            this.lblArticleTitle = new System.Windows.Forms.Label();
            this.lblArticleDetail = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btnPost = new System.Windows.Forms.Button();
            this.txtArticledetail = new System.Windows.Forms.TextBox();
            this.txtArticletitle = new System.Windows.Forms.TextBox();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.panelCreate.SuspendLayout();
            this.panelConfirm.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelCreate
            // 
            this.panelCreate.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panelCreate.Controls.Add(this.btnPost);
            this.panelCreate.Controls.Add(this.txtArticledetail);
            this.panelCreate.Controls.Add(this.txtArticletitle);
            this.panelCreate.Controls.Add(this.txtDate);
            this.panelCreate.Controls.Add(this.txtUsername);
            this.panelCreate.Controls.Add(this.label5);
            this.panelCreate.Controls.Add(this.label4);
            this.panelCreate.Controls.Add(this.label3);
            this.panelCreate.Controls.Add(this.label2);
            this.panelCreate.Controls.Add(this.label1);
            this.panelCreate.Location = new System.Drawing.Point(191, 39);
            this.panelCreate.Name = "panelCreate";
            this.panelCreate.Size = new System.Drawing.Size(525, 492);
            this.panelCreate.TabIndex = 1;
            // 
            // panelConfirm
            // 
            this.panelConfirm.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panelConfirm.Controls.Add(this.btnBack);
            this.panelConfirm.Controls.Add(this.btnConfirmPost);
            this.panelConfirm.Controls.Add(this.txtConfirmdetail);
            this.panelConfirm.Controls.Add(this.txtConfirmtitle);
            this.panelConfirm.Controls.Add(this.txtConfirmdate);
            this.panelConfirm.Controls.Add(this.txtConfirmusername);
            this.panelConfirm.Controls.Add(this.lblArticleTitle);
            this.panelConfirm.Controls.Add(this.lblArticleDetail);
            this.panelConfirm.Controls.Add(this.lblDate);
            this.panelConfirm.Controls.Add(this.lblUsername);
            this.panelConfirm.Controls.Add(this.label10);
            this.panelConfirm.Location = new System.Drawing.Point(191, 39);
            this.panelConfirm.Name = "panelConfirm";
            this.panelConfirm.Size = new System.Drawing.Size(525, 492);
            this.panelConfirm.TabIndex = 1;
            // 
            // btnConfirmPost
            // 
            this.btnConfirmPost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirmPost.Location = new System.Drawing.Point(345, 420);
            this.btnConfirmPost.Name = "btnConfirmPost";
            this.btnConfirmPost.Size = new System.Drawing.Size(111, 34);
            this.btnConfirmPost.TabIndex = 9;
            this.btnConfirmPost.Text = "Confirm";
            this.btnConfirmPost.UseVisualStyleBackColor = true;
            this.btnConfirmPost.Click += new System.EventHandler(this.btnConfirmPost_Click);
            // 
            // txtConfirmdetail
            // 
            this.txtConfirmdetail.Enabled = false;
            this.txtConfirmdetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConfirmdetail.Location = new System.Drawing.Point(184, 250);
            this.txtConfirmdetail.Multiline = true;
            this.txtConfirmdetail.Name = "txtConfirmdetail";
            this.txtConfirmdetail.Size = new System.Drawing.Size(282, 143);
            this.txtConfirmdetail.TabIndex = 8;
            // 
            // txtConfirmtitle
            // 
            this.txtConfirmtitle.Enabled = false;
            this.txtConfirmtitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConfirmtitle.Location = new System.Drawing.Point(184, 195);
            this.txtConfirmtitle.Name = "txtConfirmtitle";
            this.txtConfirmtitle.Size = new System.Drawing.Size(282, 26);
            this.txtConfirmtitle.TabIndex = 7;
            // 
            // txtConfirmdate
            // 
            this.txtConfirmdate.Enabled = false;
            this.txtConfirmdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConfirmdate.Location = new System.Drawing.Point(184, 144);
            this.txtConfirmdate.Name = "txtConfirmdate";
            this.txtConfirmdate.Size = new System.Drawing.Size(160, 26);
            this.txtConfirmdate.TabIndex = 6;
            // 
            // txtConfirmusername
            // 
            this.txtConfirmusername.Enabled = false;
            this.txtConfirmusername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConfirmusername.Location = new System.Drawing.Point(184, 90);
            this.txtConfirmusername.Name = "txtConfirmusername";
            this.txtConfirmusername.Size = new System.Drawing.Size(282, 26);
            this.txtConfirmusername.TabIndex = 5;
            // 
            // lblArticleTitle
            // 
            this.lblArticleTitle.AutoSize = true;
            this.lblArticleTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArticleTitle.Location = new System.Drawing.Point(64, 193);
            this.lblArticleTitle.Name = "lblArticleTitle";
            this.lblArticleTitle.Size = new System.Drawing.Size(86, 20);
            this.lblArticleTitle.TabIndex = 4;
            this.lblArticleTitle.Text = "Article Title";
            // 
            // lblArticleDetail
            // 
            this.lblArticleDetail.AutoSize = true;
            this.lblArticleDetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArticleDetail.Location = new System.Drawing.Point(64, 248);
            this.lblArticleDetail.Name = "lblArticleDetail";
            this.lblArticleDetail.Size = new System.Drawing.Size(98, 20);
            this.lblArticleDetail.TabIndex = 3;
            this.lblArticleDetail.Text = "Article Detail";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(64, 142);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(44, 20);
            this.lblDate.TabIndex = 2;
            this.lblDate.Text = "Date";
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsername.Location = new System.Drawing.Point(63, 90);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(83, 20);
            this.lblUsername.TabIndex = 1;
            this.lblUsername.Text = "Username";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(178, 14);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(167, 31);
            this.label10.TabIndex = 0;
            this.label10.Text = "Article Detail";
            // 
            // btnPost
            // 
            this.btnPost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPost.Location = new System.Drawing.Point(184, 420);
            this.btnPost.Name = "btnPost";
            this.btnPost.Size = new System.Drawing.Size(111, 34);
            this.btnPost.TabIndex = 9;
            this.btnPost.Text = "Post";
            this.btnPost.UseVisualStyleBackColor = true;
            this.btnPost.Click += new System.EventHandler(this.btnPost_Click);
            // 
            // txtArticledetail
            // 
            this.txtArticledetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtArticledetail.Location = new System.Drawing.Point(184, 250);
            this.txtArticledetail.Multiline = true;
            this.txtArticledetail.Name = "txtArticledetail";
            this.txtArticledetail.Size = new System.Drawing.Size(282, 143);
            this.txtArticledetail.TabIndex = 8;
            // 
            // txtArticletitle
            // 
            this.txtArticletitle.Enabled = false;
            this.txtArticletitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtArticletitle.Location = new System.Drawing.Point(184, 190);
            this.txtArticletitle.Name = "txtArticletitle";
            this.txtArticletitle.Size = new System.Drawing.Size(282, 26);
            this.txtArticletitle.TabIndex = 7;
            // 
            // txtDate
            // 
            this.txtDate.Enabled = false;
            this.txtDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDate.Location = new System.Drawing.Point(184, 138);
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(160, 26);
            this.txtDate.TabIndex = 6;
            // 
            // txtUsername
            // 
            this.txtUsername.Enabled = false;
            this.txtUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsername.Location = new System.Drawing.Point(184, 84);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(282, 26);
            this.txtUsername.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(64, 193);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Article Title";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(64, 248);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Article Detail";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(64, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(63, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "User Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(178, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Create Reply";
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(202, 420);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(111, 34);
            this.btnBack.TabIndex = 10;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // Replyarticle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(907, 571);
            this.Controls.Add(this.panelConfirm);
            this.Controls.Add(this.panelCreate);
            this.Name = "Replyarticle";
            this.Text = "Replyarticle";
            this.panelCreate.ResumeLayout(false);
            this.panelCreate.PerformLayout();
            this.panelConfirm.ResumeLayout(false);
            this.panelConfirm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelCreate;
        private System.Windows.Forms.Panel panelConfirm;
        private System.Windows.Forms.Button btnConfirmPost;
        private System.Windows.Forms.TextBox txtConfirmdetail;
        private System.Windows.Forms.TextBox txtConfirmtitle;
        private System.Windows.Forms.TextBox txtConfirmdate;
        private System.Windows.Forms.TextBox txtConfirmusername;
        private System.Windows.Forms.Label lblArticleTitle;
        private System.Windows.Forms.Label lblArticleDetail;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnPost;
        private System.Windows.Forms.TextBox txtArticledetail;
        private System.Windows.Forms.TextBox txtArticletitle;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBack;
    }
}