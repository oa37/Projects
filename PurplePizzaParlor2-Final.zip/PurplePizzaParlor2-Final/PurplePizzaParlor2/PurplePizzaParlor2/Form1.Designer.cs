﻿namespace PurplePizzaParlor2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.debugArea = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.page3Lbl = new System.Windows.Forms.Label();
            this.resetBtn = new System.Windows.Forms.Button();
            this.submitBtn = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.toppingsChkLstBox = new System.Windows.Forms.CheckedListBox();
            this.page2Lbl = new System.Windows.Forms.Label();
            this.page2txt = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.page1Lbl = new System.Windows.Forms.Label();
            this.page1Txt = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.emailField = new System.Windows.Forms.TextBox();
            this.phoneField = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.addressField = new System.Windows.Forms.TextBox();
            this.nameField = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.sizeComboBox = new System.Windows.Forms.ComboBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.submitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tabPage2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // debugArea
            // 
            this.debugArea.Location = new System.Drawing.Point(96, 574);
            this.debugArea.Multiline = true;
            this.debugArea.Name = "debugArea";
            this.debugArea.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.debugArea.Size = new System.Drawing.Size(595, 149);
            this.debugArea.TabIndex = 5;
            this.debugArea.Text = "DEBUG AREA";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.OldLace;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Purple;
            this.label1.Location = new System.Drawing.Point(216, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(356, 42);
            this.label1.TabIndex = 4;
            this.label1.Text = "Purple Pizza Parlor";
            // 
            // page3Lbl
            // 
            this.page3Lbl.AutoSize = true;
            this.page3Lbl.BackColor = System.Drawing.Color.Purple;
            this.page3Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.page3Lbl.ForeColor = System.Drawing.Color.Orange;
            this.page3Lbl.Location = new System.Drawing.Point(3, 3);
            this.page3Lbl.Name = "page3Lbl";
            this.page3Lbl.Padding = new System.Windows.Forms.Padding(0, 5, 0, 5);
            this.page3Lbl.Size = new System.Drawing.Size(194, 47);
            this.page3Lbl.TabIndex = 13;
            this.page3Lbl.Text = "Order Form";
            // 
            // resetBtn
            // 
            this.resetBtn.BackColor = System.Drawing.Color.Purple;
            this.resetBtn.ForeColor = System.Drawing.Color.Orange;
            this.resetBtn.Location = new System.Drawing.Point(289, 366);
            this.resetBtn.Name = "resetBtn";
            this.resetBtn.Size = new System.Drawing.Size(103, 34);
            this.resetBtn.TabIndex = 12;
            this.resetBtn.Text = "Reset";
            this.resetBtn.UseVisualStyleBackColor = false;
            this.resetBtn.Click += new System.EventHandler(this.ResetBtn_Click);
            // 
            // submitBtn
            // 
            this.submitBtn.BackColor = System.Drawing.Color.Purple;
            this.submitBtn.ForeColor = System.Drawing.Color.Orange;
            this.submitBtn.Location = new System.Drawing.Point(180, 366);
            this.submitBtn.Name = "submitBtn";
            this.submitBtn.Size = new System.Drawing.Size(103, 34);
            this.submitBtn.TabIndex = 11;
            this.submitBtn.Text = "Submit";
            this.submitBtn.UseVisualStyleBackColor = false;
            this.submitBtn.Click += new System.EventHandler(this.SubmitBtn_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(314, 111);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 20);
            this.label8.TabIndex = 10;
            this.label8.Text = "Toppings:";
            // 
            // toppingsChkLstBox
            // 
            this.toppingsChkLstBox.CheckOnClick = true;
            this.toppingsChkLstBox.FormattingEnabled = true;
            this.toppingsChkLstBox.Items.AddRange(new object[] {
            "Sausage",
            "Pepperoni",
            "Hamburger",
            "Onions",
            "Green Peppers",
            "Mushrooms"});
            this.toppingsChkLstBox.Location = new System.Drawing.Point(334, 138);
            this.toppingsChkLstBox.Name = "toppingsChkLstBox";
            this.toppingsChkLstBox.Size = new System.Drawing.Size(173, 130);
            this.toppingsChkLstBox.TabIndex = 9;
            this.toppingsChkLstBox.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.ToppingsChkLstBox_ItemCheck);
            // 
            // page2Lbl
            // 
            this.page2Lbl.AutoSize = true;
            this.page2Lbl.BackColor = System.Drawing.Color.Purple;
            this.page2Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.page2Lbl.ForeColor = System.Drawing.Color.Orange;
            this.page2Lbl.Location = new System.Drawing.Point(-1, 3);
            this.page2Lbl.Name = "page2Lbl";
            this.page2Lbl.Padding = new System.Windows.Forms.Padding(0, 5, 0, 5);
            this.page2Lbl.Size = new System.Drawing.Size(183, 47);
            this.page2Lbl.TabIndex = 3;
            this.page2Lbl.Text = "About PPP";
            // 
            // page2txt
            // 
            this.page2txt.BackColor = System.Drawing.Color.OldLace;
            this.page2txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.page2txt.Location = new System.Drawing.Point(3, 53);
            this.page2txt.Multiline = true;
            this.page2txt.Name = "page2txt";
            this.page2txt.ReadOnly = true;
            this.page2txt.Size = new System.Drawing.Size(592, 53);
            this.page2txt.TabIndex = 2;
            this.page2txt.Text = "PPP is a figment of a demented professor\'s imagination.";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.OldLace;
            this.tabPage2.Controls.Add(this.page2Lbl);
            this.tabPage2.Controls.Add(this.page2txt);
            this.tabPage2.ForeColor = System.Drawing.Color.Purple;
            this.tabPage2.Location = new System.Drawing.Point(4, 33);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(595, 425);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "About";
            // 
            // page1Lbl
            // 
            this.page1Lbl.AutoSize = true;
            this.page1Lbl.BackColor = System.Drawing.Color.Purple;
            this.page1Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.page1Lbl.ForeColor = System.Drawing.Color.Orange;
            this.page1Lbl.Location = new System.Drawing.Point(3, 3);
            this.page1Lbl.Name = "page1Lbl";
            this.page1Lbl.Padding = new System.Windows.Forms.Padding(0, 5, 0, 5);
            this.page1Lbl.Size = new System.Drawing.Size(167, 47);
            this.page1Lbl.TabIndex = 1;
            this.page1Lbl.Text = "Welcome!";
            // 
            // page1Txt
            // 
            this.page1Txt.BackColor = System.Drawing.Color.OldLace;
            this.page1Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.page1Txt.Location = new System.Drawing.Point(3, 53);
            this.page1Txt.Multiline = true;
            this.page1Txt.Name = "page1Txt";
            this.page1Txt.ReadOnly = true;
            this.page1Txt.Size = new System.Drawing.Size(589, 53);
            this.page1Txt.TabIndex = 0;
            this.page1Txt.Text = "Welcome to the Purple Pizza Parlor located at a University near you!";
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.OldLace;
            this.tabPage1.Controls.Add(this.page1Lbl);
            this.tabPage1.Controls.Add(this.page1Txt);
            this.tabPage1.ForeColor = System.Drawing.Color.Purple;
            this.tabPage1.Location = new System.Drawing.Point(4, 33);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(595, 425);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Home";
            // 
            // emailField
            // 
            this.emailField.Location = new System.Drawing.Point(109, 240);
            this.emailField.Name = "emailField";
            this.emailField.Size = new System.Drawing.Size(172, 26);
            this.emailField.TabIndex = 7;
            // 
            // phoneField
            // 
            this.phoneField.Location = new System.Drawing.Point(109, 208);
            this.phoneField.Name = "phoneField";
            this.phoneField.Size = new System.Drawing.Size(172, 26);
            this.phoneField.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 248);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 20);
            this.label7.TabIndex = 5;
            this.label7.Text = "Email:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 214);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 20);
            this.label6.TabIndex = 4;
            this.label6.Text = "Telephone:";
            // 
            // addressField
            // 
            this.addressField.Location = new System.Drawing.Point(109, 100);
            this.addressField.Multiline = true;
            this.addressField.Name = "addressField";
            this.addressField.Size = new System.Drawing.Size(172, 102);
            this.addressField.TabIndex = 3;
            // 
            // nameField
            // 
            this.nameField.Location = new System.Drawing.Point(109, 68);
            this.nameField.Name = "nameField";
            this.nameField.Size = new System.Drawing.Size(172, 26);
            this.nameField.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 103);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 20);
            this.label5.TabIndex = 1;
            this.label5.Text = "Address:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(6, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "Name:";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.OldLace;
            this.tabPage3.Controls.Add(this.pictureBox1);
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Controls.Add(this.sizeComboBox);
            this.tabPage3.Controls.Add(this.page3Lbl);
            this.tabPage3.Controls.Add(this.resetBtn);
            this.tabPage3.Controls.Add(this.submitBtn);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.toppingsChkLstBox);
            this.tabPage3.Controls.Add(this.emailField);
            this.tabPage3.Controls.Add(this.phoneField);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.addressField);
            this.tabPage3.Controls.Add(this.nameField);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.label4);
            this.tabPage3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage3.ForeColor = System.Drawing.Color.Black;
            this.tabPage3.Location = new System.Drawing.Point(4, 33);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(595, 425);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Order";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(542, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 450);
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(314, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 20);
            this.label2.TabIndex = 15;
            this.label2.Text = "Size:";
            // 
            // sizeComboBox
            // 
            this.sizeComboBox.FormattingEnabled = true;
            this.sizeComboBox.Items.AddRange(new object[] {
            "Extra Large",
            "Large",
            "Medium",
            "Small",
            "Extra Small"});
            this.sizeComboBox.Location = new System.Drawing.Point(386, 68);
            this.sizeComboBox.Name = "sizeComboBox";
            this.sizeComboBox.Size = new System.Drawing.Size(121, 28);
            this.sizeComboBox.TabIndex = 8;
            this.sizeComboBox.Text = "Large";
            this.sizeComboBox.SelectedIndexChanged += new System.EventHandler(this.SizeComboBox_SelectedIndexChanged);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(92, 91);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(603, 462);
            this.tabControl1.TabIndex = 3;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(787, 25);
            this.toolStrip1.TabIndex = 6;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.submitToolStripMenuItem,
            this.resetToolStripMenuItem,
            this.toolStripSeparator1,
            this.quitToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(29, 22);
            this.toolStripDropDownButton1.Text = "toolStripDropDownButton1";
            // 
            // submitToolStripMenuItem
            // 
            this.submitToolStripMenuItem.Name = "submitToolStripMenuItem";
            this.submitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.S)));
            this.submitToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.submitToolStripMenuItem.Text = "Submit";
            this.submitToolStripMenuItem.Click += new System.EventHandler(this.SubmitBtn_Click);
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.R)));
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.resetToolStripMenuItem.Text = "Reset";
            this.resetToolStripMenuItem.Click += new System.EventHandler(this.ResetBtn_Click);
            // 
            // quitToolStripMenuItem
            // 
            this.quitToolStripMenuItem.Name = "quitToolStripMenuItem";
            this.quitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.Q)));
            this.quitToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.quitToolStripMenuItem.Text = "Quit";
            this.quitToolStripMenuItem.Click += new System.EventHandler(this.QuitToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(177, 6);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(787, 750);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.debugArea);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Purple Pizza Parlor - Version 2";
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox debugArea;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label page3Lbl;
        private System.Windows.Forms.Button resetBtn;
        private System.Windows.Forms.Button submitBtn;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckedListBox toppingsChkLstBox;
        private System.Windows.Forms.Label page2Lbl;
        private System.Windows.Forms.TextBox page2txt;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label page1Lbl;
        private System.Windows.Forms.TextBox page1Txt;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox emailField;
        private System.Windows.Forms.TextBox phoneField;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox addressField;
        private System.Windows.Forms.TextBox nameField;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox sizeComboBox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem submitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem quitToolStripMenuItem;
    }
}

