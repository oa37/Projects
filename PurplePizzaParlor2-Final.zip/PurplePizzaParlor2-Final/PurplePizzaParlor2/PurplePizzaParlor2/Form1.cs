﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PurplePizzaParlor2
{
    public partial class Form1 : Form
    {
        // Application data
        const string fileName = "../../../output.txt";

        public Form1()
        {
            InitializeComponent();
            debugArea.Text += Environment.NewLine;
            // pad headings
            int pageWidth = tabPage1.Size.Width;
            int pageHeadingWidth = page1Lbl.Size.Width;
            int padding = (pageWidth - pageHeadingWidth) / 2;
            page1Lbl.Padding = new System.Windows.Forms.Padding(padding, 5, padding, 5);
            pageHeadingWidth = page2Lbl.Size.Width;
            padding = (pageWidth - pageHeadingWidth) / 2;
            page2Lbl.Padding = new System.Windows.Forms.Padding(padding, 5, padding, 5);
            pageHeadingWidth = page3Lbl.Size.Width;
            padding = (pageWidth - pageHeadingWidth) / 2;
            page3Lbl.Padding = new System.Windows.Forms.Padding(padding, 5, padding, 5);
        }

        private void SubmitBtn_Click(object sender, EventArgs e)
        {
            if (nameField.Text == "")
            {
                MessageBox.Show("Please enter a name");
                return;
            }
            if (addressField.Text == "")
            {
                MessageBox.Show("Please enter an address");
                return;
            }
            String message = "Name: " + nameField.Text + Environment.NewLine
                + "Address:" + Environment.NewLine + addressField.Text + Environment.NewLine
                + "Telephone: " + phoneField.Text + Environment.NewLine
                + "Email: " + emailField.Text + Environment.NewLine
                + "Size: " + sizeComboBox.Items[sizeComboBox.SelectedIndex] + Environment.NewLine;
            String toppings = "None";
            int numChecked = toppingsChkLstBox.CheckedItems.Count;
            if (numChecked > 0)
            {
                toppings = toppingsChkLstBox.CheckedItems[0].ToString();
                for (int i = 1; i < numChecked; i++)
                {
                    toppings = toppings + ", " + toppingsChkLstBox.CheckedItems[i];
                }
            }
            message += "Toppings: " + toppings + Environment.NewLine;
            debugArea.Text += message;

            StreamWriter fileOutput = new StreamWriter(fileName, true);
               // second argument is true for append
            fileOutput.Write(message);
            fileOutput.WriteLine("----------------------");
            fileOutput.Close();
            
        }

        private void ToppingsChkLstBox_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            if (e.NewValue == CheckState.Checked)
                debugArea.Text += "Toppings check box " + toppingsChkLstBox.Items[e.Index]
                    + " has been checked" + Environment.NewLine;
            else if (e.NewValue == CheckState.Unchecked)
                debugArea.Text += "Toppings check box " + toppingsChkLstBox.Items[e.Index]
                    + " has been unchecked" + Environment.NewLine;
        }

        private void ResetBtn_Click(object sender, EventArgs e)
        {
            nameField.Text = "";
            addressField.Text = "";
            phoneField.Text = "";
            emailField.Text = "";

            sizeComboBox.SelectedIndex = 1;  // Large
            
            int numChecked = toppingsChkLstBox.CheckedIndices.Count;
            // Copy the indexes of checked boxes
            int[] indexes = new int[numChecked];
            for (int i = 0; i < numChecked; i++)
                indexes[i] = toppingsChkLstBox.CheckedIndices[i];
            // Uncheck the checked boxes
            for (int i = 0; i < numChecked; i++)
                toppingsChkLstBox.SetItemCheckState(indexes[i], CheckState.Unchecked);

        }

        private void SizeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;
            if (cb == null)
            {
                MessageBox.Show("Sender is not a ComboBox");
                return;
            }
            debugArea.Text += "Size combo boxed changed to " + cb.Items[cb.SelectedIndex] + Environment.NewLine;
        }

        private void QuitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
