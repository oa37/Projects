﻿namespace ReadOrders
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.orderBox = new System.Windows.Forms.TextBox();
            this.readBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // orderBox
            // 
            this.orderBox.Location = new System.Drawing.Point(4, 4);
            this.orderBox.Multiline = true;
            this.orderBox.Name = "orderBox";
            this.orderBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.orderBox.Size = new System.Drawing.Size(277, 256);
            this.orderBox.TabIndex = 0;
            // 
            // readBtn
            // 
            this.readBtn.Location = new System.Drawing.Point(110, 279);
            this.readBtn.Name = "readBtn";
            this.readBtn.Size = new System.Drawing.Size(75, 23);
            this.readBtn.TabIndex = 1;
            this.readBtn.Text = "Read Orders";
            this.readBtn.UseVisualStyleBackColor = true;
            this.readBtn.Click += new System.EventHandler(this.ReadBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 314);
            this.Controls.Add(this.readBtn);
            this.Controls.Add(this.orderBox);
            this.Name = "Form1";
            this.Text = "Read Orders";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox orderBox;
        private System.Windows.Forms.Button readBtn;
    }
}

