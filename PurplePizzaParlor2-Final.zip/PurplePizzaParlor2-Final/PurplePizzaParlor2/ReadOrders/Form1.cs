﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;

namespace ReadOrders
{
    public partial class Form1 : Form
    {
        // Application data
        const String fileName = "../../../output.txt";
        System.Timers.Timer tmr;  // timer object

        // delegate has the same signature as function to be called
        private delegate void SafeCallDelegate(string text);  
          
        public Form1()
        {
            InitializeComponent();
            tmr = new System.Timers.Timer(30000);  // 30 seconds
            tmr.Elapsed += new ElapsedEventHandler(Tmr_ElapsedEvent);
            tmr.Start();

        }

        // Function to set the orderBox text
        private void WriteTextSafe(string text)
        {
            if (orderBox.InvokeRequired)  // calling thread is not same as creating (main) thread
            {
                // initialize delegate that was declared by the main thread
                var d = new SafeCallDelegate(WriteTextSafe);

                // invoke the delegate with argument array, runs function the main thread
                orderBox.Invoke(d, new object[] { text });    
            }
            else
            {
                orderBox.Text = text;
            }
        }

        private void ReadInfo ()
        {
            StreamReader fileInput = new StreamReader(fileName);
            string content = fileInput.ReadToEnd();
            fileInput.Close();

            WriteTextSafe(content);
            
        }

        private void ReadBtn_Click(object sender, EventArgs e)
        {
                ReadInfo();
        }

        private void Tmr_ElapsedEvent(object sender, ElapsedEventArgs e)
        {
            ReadInfo();
        }
    
    }
}
